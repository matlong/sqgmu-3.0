% The forward dyadic wavelet trasnsform with the Algorithme a
% trous is not yet implemented in Wavelab. It is implemented in the
% LastWave software, which is available on the Internet at
% http://www.cmap.polytechnique.fr/users/www.bacry
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:40 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
