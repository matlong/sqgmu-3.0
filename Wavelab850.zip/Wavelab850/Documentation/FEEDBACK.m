% FEEDBACK -- Encouraging User Feedback about WaveLab
%
% Please let us have your comments and suggestions!
%
% e-mail:
%     wavelab@stat.stanford.edu
%
% Individuals:
%     Ofer Levi  	levio@stat.stanford.edu
%     Mark Dunjcan  mduncan@stat.stanford.edu
%     Dave Donoho   donoho@stat.stanford.edu
% 

% Revision History
%		10/02/99	DLD 	updated e-mails addresses 
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:40 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
