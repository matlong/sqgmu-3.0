function r = rms(y)% rms -- Return Root Mean Square of Signal%  Usage%    r = rms(y)%  Inputs%    y    signal%  Outputs%    r    sqrt( mean ( y .^2 ))%r = sqrt( mean ( y .^2 ));         
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:41 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
